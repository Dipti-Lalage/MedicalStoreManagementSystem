package custome_exception;

@SuppressWarnings("serial")
public class MedicalShopNotFoundException extends RuntimeException {
	public MedicalShopNotFoundException(String msg) {
	  super(msg);
	}

}
