package custome_exception;

@SuppressWarnings("serial")
public class StaffNotFoundException extends RuntimeException {
	public StaffNotFoundException(String msg) {
		super(msg);
	}
}
