package custome_exception;

@SuppressWarnings("serial")
public class CompanyNotFoundException extends RuntimeException {
	public CompanyNotFoundException(String msg) {
		super(msg);
	}
}
