package custome_exception;

@SuppressWarnings("serial")
public class MedicineNotFoundException extends RuntimeException{
	public MedicineNotFoundException(String msg) {
		super(msg);
	}

}
