package com.app.pojos;

import javax.persistence.*;

@Entity
@Table(name = "companies")
public class Company {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = " company_id")
	private Integer companyId;

	@Column(length = 50, name = "company_name")
	private String companyName;

	@Column(length = 50, name = "company_address")
	private String companyAddress;

	@Column(length = 300, name = "company_description")
	private String companyDescription;

	public Company() {
		System.out.println("in def const of " + getClass().getName());
	}

	public Company(String companyName, String companyAddress, String companyDescription) {
		super();
		this.companyName = companyName;
		this.companyAddress = companyAddress;
		this.companyDescription = companyDescription;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getCompanyAddress() {
		return companyAddress;
	}

	public void setCompanyAddress(String companyAddress) {
		this.companyAddress = companyAddress;
	}

	public String getCompanyDescription() {
		return companyDescription;
	}

	public void setCompanyDescription(String companyDescription) {
		this.companyDescription = companyDescription;
	}

	public Integer getCompanyId() {
		return companyId;
	}

	@Override
	public String toString() {
		return "Company [companyId=" + companyId + ", comapnyName=" + companyName + ", companyAddress=" + companyAddress
				+ ", companyDescription=" + companyDescription + "]";
	}

}
