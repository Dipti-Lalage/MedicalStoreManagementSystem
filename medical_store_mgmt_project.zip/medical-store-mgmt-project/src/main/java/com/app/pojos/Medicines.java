
package com.app.pojos;

import java.time.LocalDate;

import javax.persistence.*;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonInclude;

@Entity
@Table(name = "medicines")

public class Medicines {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "medicine_id")
	private Integer medicineId;

	@ManyToOne
	@JoinColumn(name = "medical_shop_id", nullable = false)
	private MedicalShop medicalShopId;

	@Column(length = 100, name = "medicine_name")
	private String medicineName;

	@Column(length = 100, name = "company_name")
	private String companyName;

	@Column(name = "available_stock", nullable = false)
	private int availbleStocks;

	@Column(name = "minimum_stock", nullable = false)
	private int minimumStocks;

	@Column(name = "medicine_cost")
	private double medicineCost;

	@Column(name = "mfg_date")
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private LocalDate mfgDate;

	@Column(name = "exp_date")
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private LocalDate expDate;

	@Column(length = 100, name = "medicine_description")
	private String medicineDescription;

	public Medicines() {
		System.out.println("In def const of " + getClass().getName());
	}

	public Medicines(Integer medicineId, MedicalShop medicalShopId, String medicineName, String companyName,
			int availbleStocks, int minimumStocks, double medicineCost, LocalDate mfgDate, LocalDate expDate,
			String medicineDescription) {
		super();
		this.medicineId = medicineId;
		this.medicalShopId = medicalShopId;
		this.medicineName = medicineName;
		this.companyName = companyName;
		this.availbleStocks = availbleStocks;
		this.minimumStocks = minimumStocks;
		this.medicineCost = medicineCost;
		this.mfgDate = mfgDate;
		this.expDate = expDate;
		this.medicineDescription = medicineDescription;
	}

	public String getMedicineName() {
		return medicineName;
	}

	public void setMedicineName(String medicineName) {
		this.medicineName = medicineName;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public int getAvailbleStocks() {
		return availbleStocks;
	}

	public void setAvailbleStocks(int availbleStocks) {
		this.availbleStocks = availbleStocks;
	}

	public int getMinimumStocks() {
		return minimumStocks;
	}

	public void setMinimumStocks(int minimumStocks) {
		this.minimumStocks = minimumStocks;
	}

	public double getMedicineCost() {
		return medicineCost;
	}

	public void setMedicineCost(double medicineCost) {
		this.medicineCost = medicineCost;
	}

	public LocalDate getMfgDate() {
		return mfgDate;
	}

	public void setMfgDate(LocalDate mfgDate) {
		this.mfgDate = mfgDate;
	}

	public LocalDate getExpDate() {
		return expDate;
	}

	public void setExpDate(LocalDate expDate) {
		this.expDate = expDate;
	}

	public String getMedicineDescription() {
		return medicineDescription;
	}

	public void setMedicineDescription(String medicineDescription) {
		this.medicineDescription = medicineDescription;
	}

	public Integer getMedicineId() {
		return medicineId;
	}

	public MedicalShop getMedicalShopId() {
		return medicalShopId;
	}

	@Override
	public String toString() {
		return "Medicines [medicalShopId=" + medicalShopId + ", medicineName=" + medicineName + ", companyName="
				+ companyName + ", availbleStocks=" + availbleStocks + ", minimumStocks=" + minimumStocks
				+ ", medicineCost=" + medicineCost + ", mfgDate=" + mfgDate + ", expDate=" + expDate
				+ ", medicineDescription=" + medicineDescription + "]";
	}

}