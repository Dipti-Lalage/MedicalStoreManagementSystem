package com.app.pojos;

import javax.persistence.*;

@Entity
@Table(name = "medical_shop")
public class MedicalShop {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "medical_shop_id")
	private Integer medicalShopId;

	@Column(length = 40, name = "medical_shop_name", unique = true)
	private String medicalShopName;

	@Column(length = 50, name = "medical_shop_address")
	private String medicalShopAddress;

	@Column(length = 50, name = "owner_name")
	private String ownerName;

	@Column(length = 10, name = "owner_mobile")
	private String ownerMobile;

	@Column(length = 30, unique = true, name = "owner_email")
	private String ownerEmail;

	@Column(length = 20, unique = true, name = "owner_password")
	private String ownerPassword;

	@Column(length = 50, name = "owner_address")
	private String ownerAddress;

	@Column(length = 50, name = "  medical_shop_description")
	private String medicalShopDescription;

	public MedicalShop() {
		System.out.println("In constr of " + getClass().getName());
	}

	public MedicalShop(String medicalShopName, String medicalShopAddress, String ownerName, String ownerMobile,
			String ownerEmail, String ownerPassword, String ownerAddress, String medicalShopDescription) {
		super();
		this.medicalShopName = medicalShopName;
		this.medicalShopAddress = medicalShopAddress;
		this.ownerName = ownerName;
		this.ownerMobile = ownerMobile;
		this.ownerEmail = ownerEmail;
		this.ownerPassword = ownerPassword;
		this.ownerAddress = ownerAddress;
		this.medicalShopDescription = medicalShopDescription;
	}


	public void setMedicalShopId(Integer medicalShopId) {
		this.medicalShopId = medicalShopId;
	}

	public String getMedicalShopName() {
		return medicalShopName;
	}

	public void setMedicalShopName(String medicalShopName) {
		this.medicalShopName = medicalShopName;
	}

	public String getMedicalShopAddress() {
		return medicalShopAddress;
	}

	public void setMedicalShopAddress(String medicalShopAddress) {
		this.medicalShopAddress = medicalShopAddress;
	}

	public String getOwnerName() {
		return ownerName;
	}

	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}

	public String getOwnerMobile() {
		return ownerMobile;
	}

	public void setOwnerMobile(String ownerMobile) {
		this.ownerMobile = ownerMobile;
	}

	public String getOwnerEmail() {
		return ownerEmail;
	}

	public void setOwnerEmail(String ownerEmail) {
		this.ownerEmail = ownerEmail;
	}

	public String getOwnerPassword() {
		return ownerPassword;
	}

	public void setOwnerPassword(String ownerPassword) {
		this.ownerPassword = ownerPassword;
	}

	public String getOwnerAddress() {
		return ownerAddress;
	}

	public void setOwnerAddress(String ownerAddress) {
		this.ownerAddress = ownerAddress;
	}

	public String getMedicalShopDescription() {
		return medicalShopDescription;
	}

	public void setMedicalShopDescription(String medicalShopDescription) {
		this.medicalShopDescription = medicalShopDescription;
	}

	public Integer getMedicalShopId() {
		return medicalShopId;
	}

	@Override
	public String toString() {
		return "MedicalShop [medicalShopId=" + medicalShopId + ", medicalShopName=" + medicalShopName
				+ ", medicalShopAddress=" + medicalShopAddress + ", ownerName=" + ownerName + ", ownerMobile="
				+ ownerMobile + ", ownerEmail=" + ownerEmail + ", ownerPassword=" + ownerPassword + ", ownerAddress="
				+ ownerAddress + ", medicalShopDescription=" + medicalShopDescription + "]";
	}

}
