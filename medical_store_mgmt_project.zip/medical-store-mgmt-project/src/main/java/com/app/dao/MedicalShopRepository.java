package com.app.dao;


import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.app.pojos.MedicalShop;

public interface MedicalShopRepository extends JpaRepository<MedicalShop, Integer>{

   Optional<MedicalShop> findByMedicalShopName(String medicalShopName);
  public MedicalShop findByOwnerEmail(String email);
  public MedicalShop findByOwnerPassword(String pass);
 
}
