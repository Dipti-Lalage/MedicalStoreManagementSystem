package com.app.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.app.pojos.Company;

public interface MedicineCompanyRepository extends JpaRepository<Company, Integer>{
	Optional<Company> findByCompanyName(String companyName);
}
