package com.app.services;

import com.app.pojos.Administrator;


public interface IAdministratorService {
	 Administrator fetchLoginAdmin(String email,String Pass);

}
