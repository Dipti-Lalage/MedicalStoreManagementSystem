package com.app.services;

import java.util.List;

import com.app.pojos.MedicalShop;

public interface IMedicalShopService {
	MedicalShop addMedicalShop(MedicalShop ms);
	List<MedicalShop> getAllMedicalShops();
	MedicalShop UpdateShopDetails(MedicalShop ms);
	void deleteMedicalShop(int shopid);
	 MedicalShop  getMedicalshopDetails(int shopId);
	 MedicalShop fetchLoginOwner(String email,String Pass);
}
