package com.app.services;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.dao.MedicineCompanyRepository;
import com.app.pojos.Company;


import custome_exception.CompanyNotFoundException;



@Service
@Transactional
public class CompanyServiceImpl implements IComapnyService {

	@Autowired
	private MedicineCompanyRepository repo;
	
	@Override
	public Company addNewCompany(Company c) {
	
		return repo.save(c);
	}

	@Override
	public List<Company> getAllCompanies() {
	
		return repo.findAll();
	}

	@Override
	public Company updateCompanyDetails(Company c) {
		Optional<Company> optional=repo.findByCompanyName(c.getCompanyName());
		if(optional.isPresent())
		return repo.save(c);
		else
		throw new CompanyNotFoundException("Comapny not found : Invalid company id"+c.getCompanyName());
	}

	@Override
	public void deleteCompany(int companyId) {
		Optional<Company> optional = repo.findById(companyId);
				if(optional.isPresent())
			repo.deleteById(companyId);
	else
		throw new CompanyNotFoundException("Company not found : Invalid Company id"+companyId);
		
	}

	@Override
	public Company getCompanyDetails(int companyId) {
		Optional<Company> optionalCompany = repo.findById(companyId);
		if (optionalCompany.isPresent())
			return repo.getOne(companyId);
		else
		throw new CompanyNotFoundException("Company not found: Invalid ID " + companyId);
	}
	
	
}
