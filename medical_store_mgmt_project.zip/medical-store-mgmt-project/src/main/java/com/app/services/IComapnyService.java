package com.app.services;

import java.util.List;

import com.app.pojos.Company;



public interface IComapnyService {
	Company addNewCompany(Company c);
	List<Company> getAllCompanies();
	Company updateCompanyDetails(Company c);
	void deleteCompany(int companyId);
	Company  getCompanyDetails(int companyId);
}
