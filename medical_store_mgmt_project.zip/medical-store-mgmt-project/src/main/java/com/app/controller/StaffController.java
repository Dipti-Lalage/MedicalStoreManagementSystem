package com.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.pojos.MedicalShop;
import com.app.pojos.Staff;
import com.app.services.IStaffService;

import custome_exception.MedicalShopNotFoundException;
import custome_exception.StaffNotFoundException;

@RestController
@RequestMapping("/staff")
@CrossOrigin
public class StaffController {
	
	@Autowired
	private IStaffService service;
	
	public StaffController() {
		System.out.println("in def conrt "+getClass().getName());
	}
	@PostMapping("/stafflogin")
	public Staff LoginStaff(@RequestBody Staff s )
	{
		System.out.println("in LoginStaff "+s);
		String email=s.getStaffEmail();
		String pass=s.getStaffPassword();
		Staff staff=null;
		if(email!=null && pass!=null)
			staff=service.fetchLoginStaff(email, pass);	
		if(staff==null)
			throw new StaffNotFoundException("Wrong Credentils ... Please try again");
		return staff;
	}
	@GetMapping
	public ResponseEntity<?> SatffList() {
		System.out.println("in SatffList " );
	    List<Staff> staff=service.getAllStaff();
		if(staff.isEmpty())
		    return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		else
			return new ResponseEntity<>(staff,HttpStatus.OK);
		
	}
	@PostMapping
	public ResponseEntity<?> addNewStaff(@RequestBody Staff s)
	{
		System.out.println("in addNewStaff "+s);
		return ResponseEntity.ok(service.addNewStaff(s));
	}

	
	@PutMapping
	public ResponseEntity<?> updateStaffDetails(@RequestBody Staff s) {
		System.out.println("in updateStaffDetails " + s);
		try {
			return ResponseEntity.ok(service.updateStaffDetails(s));
		} catch (RuntimeException e) {
			System.out.println("err in controller " + e);
		}
		return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	}
	
	@DeleteMapping("/{staffId}")
	public void deleteStaffDetails(@PathVariable int staffId) {
		System.out.println("in deleteStaffDetails " + staffId);
		try {
			service.deleteStaff(staffId);
			
		} catch (RuntimeException e) {
			System.out.println("err in controller " + e);
		}
	}
	@GetMapping("/{staffid}")
	public ResponseEntity<?> getStaffDetails(@PathVariable int staffid) {
		System.out.println("in get Saff dtls " + staffid);
		try {
			return ResponseEntity.ok(service.getStaffDetails(staffid));
		} catch (RuntimeException e) {
			System.out.println("err in controller " + e);
		}
		return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	}
}
