package com.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.pojos.Company;

import com.app.services.IComapnyService;

@RestController
@RequestMapping("/company")
@CrossOrigin
public class CompanyController {

	@Autowired
	private IComapnyService service;

	public CompanyController() {
		System.out.println("In contrl of " + getClass().getName());
	}

	@GetMapping
	public ResponseEntity<?> MedicineCompanyList() {
		System.out.println("in list comapny list ");
		List<Company> company = service.getAllCompanies();
		if (company.isEmpty())
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		else
			return new ResponseEntity<>(company, HttpStatus.OK);

	}
	
	@PostMapping
	public ResponseEntity<?> addNewCompany(@RequestBody Company c)
	{
		System.out.println("in addnewcompany "+c);
		return ResponseEntity.ok(service.addNewCompany(c));
	}

	
	
	@PutMapping
	public ResponseEntity<?> updateComapnyDetails(@RequestBody Company c) {
		System.out.println("in update comapny " + c);
		try {
			return ResponseEntity.ok(service.updateCompanyDetails(c));
		} catch (RuntimeException e) {
			System.out.println("err in controller " + e);
		}
		return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	}
	
	@DeleteMapping("/{companyId}")
	public void deleteCompanyDetails(@PathVariable int companyId) {
		System.out.println("in del company dtls " + companyId);
		try {
			service.deleteCompany(companyId);
			
		} catch (RuntimeException e) {
			System.out.println("err in controller " + e);
		}
	}
	@GetMapping("/{companyid}")
	public ResponseEntity<?> getCompanyDetails(@PathVariable int companyid) {
		System.out.println("in get company dtls " + companyid);
		try {
			return ResponseEntity.ok(service.getCompanyDetails(companyid));
		} catch (RuntimeException e) {
			System.out.println("err in controller " + e);
		}
		return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	}
}
