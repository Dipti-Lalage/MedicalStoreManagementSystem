package com.app.controller;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;



@CrossOrigin
@RestController
@RequestMapping("/index")
public class HomeController {

	@Autowired

	
	
	public HomeController() {
		System.out.println("in contr of " + getClass().getName());
	}

	/*@PostMapping("/login")
	public MedicalShop LoginOwner(@RequestBody MedicalShop m )
	{
		System.out.println("in LoginOwner "+m);
		String email=m.getOwnerEmail();
		String pass=m.getOwnerPassword();
		MedicalShop owner=null;
		if(email!=null && pass!=null)
			owner=service.LoginOwner(email, pass);	
		if(owner==null)
			throw new MedicalShopNotFoundException("Wrong Credentils ... Please try again");
		return owner;
	}*/

}
