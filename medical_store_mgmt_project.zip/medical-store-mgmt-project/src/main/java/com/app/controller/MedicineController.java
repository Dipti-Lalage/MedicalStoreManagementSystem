package com.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;



import com.app.pojos.Medicines;
import com.app.services.IMedicineService;

@Controller
@RequestMapping(value="/medicines")
@CrossOrigin
public class MedicineController {

	@Autowired
	private IMedicineService service;

	public MedicineController() {
		System.out.println("In contrl of " + getClass().getName());
	}

	@GetMapping
	public ResponseEntity<?> MedicinesList() {
		System.out.println("in  medicines list ");
		List<Medicines> medicine = service.getAllMedicines();
		if (medicine.isEmpty())
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		else
			return new ResponseEntity<>(medicine, HttpStatus.OK);

	}

	@PostMapping("/addmedicine")
	public ResponseEntity<?> addNewCompany(@RequestBody Medicines m) {
		System.out.println("in addNewCompany " + m);
		return ResponseEntity.ok(service.addNewMedicines(m));
	}

	@PutMapping
	public ResponseEntity<?> updateMedicinesDetails(@RequestBody Medicines m) {
		System.out.println("in updateMedicinesDetails" + m);
		try {
			return ResponseEntity.ok(service.updateMedicineDetails(m));
		} catch (RuntimeException e) {
			System.out.println("err in controller " + e);
		}
		return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	}

	@DeleteMapping("/{medicineId}")
	public void deleteMedicinesDetails(@PathVariable int medicineId) {
		System.out.println("in del company dtls " + medicineId);
		try {
			service.deleteMedicine(medicineId);

		} catch (RuntimeException e) {
			System.out.println("err in controller " + e);
		}
	}
	
	@GetMapping("/{medicineid}")
	public ResponseEntity<?> getMedicineDetails(@PathVariable int medicineid) {
		System.out.println("in get medicine dtls " + medicineid);
		try {
			return ResponseEntity.ok(service.getMedicineDetails(medicineid));
		} catch (RuntimeException e) {
			System.out.println("err in controller " + e);
		}
		return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	}
	
}
