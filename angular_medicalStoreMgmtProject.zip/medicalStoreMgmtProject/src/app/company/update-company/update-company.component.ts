import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Company } from '../company.model';
import { CompanyService } from '../company.service';

@Component({
  selector: 'app-update-company',
  templateUrl: './update-company.component.html',
  styleUrls: ['./update-company.component.css']
})
export class UpdateCompanyComponent implements OnInit {

    companyid:number;
    company:Company;
  constructor(private route:ActivatedRoute,private router:Router,
              private service:CompanyService) { }

  ngOnInit(): void {
    this.company=new Company();
    this.companyid=this.route.snapshot.params['companyId'];

    this.service.getCompany(this.companyid)
    .subscribe(data=>{
      console.log(data)
      this.company=data;
    },error=>console.error(error) );
  }
  updateCompany()
  {
    this.service.updateCompanyDetails(this.company)
    .subscribe(data=>console.log(data),error=>console.log(error));
    this.company=new Company();
    this.gotoList();
  }
  onSubmit() {
    this.updateCompany();    
  }

  gotoList() {
    this.router.navigate(['displayowner/company']);
  }
}
