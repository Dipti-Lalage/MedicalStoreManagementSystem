export class Company{
    companyId:number;
    companyName:string;
    companyAddress:string;
    companyDescription:string;
}