import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ShowCompanyComponent } from './show-company/show-company.component';
import { UpdateCompanyComponent } from './update-company/update-company.component';
import { DetailsCompanyComponent } from './details-company/details-company.component';
import { AddCompanyComponent } from './add-company/add-company.component';



@NgModule({
  declarations: [ShowCompanyComponent, UpdateCompanyComponent, DetailsCompanyComponent, AddCompanyComponent],
  imports: [
    CommonModule
  ]
})
export class CompanyModule { }
