import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DetailsMedicalshopComponent } from './details-medicalshop.component';

describe('DetailsMedicalshopComponent', () => {
  let component: DetailsMedicalshopComponent;
  let fixture: ComponentFixture<DetailsMedicalshopComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DetailsMedicalshopComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DetailsMedicalshopComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
