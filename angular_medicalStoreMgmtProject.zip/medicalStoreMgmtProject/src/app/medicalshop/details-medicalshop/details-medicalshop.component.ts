import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { MedicalShopService } from '../medical-shop.service';
import { MedicalShop } from '../medicalshop.model';

@Component({
  selector: 'app-details-medicalshop',
  templateUrl: './details-medicalshop.component.html',
  styleUrls: ['./details-medicalshop.component.css']
})
export class DetailsMedicalshopComponent implements OnInit {

  shopId:number;
  shops:MedicalShop;

  constructor(private route:ActivatedRoute,private router:Router,
              private service:MedicalShopService) { }

  ngOnInit(): void {
    this.shops=new MedicalShop();
    this.shopId=this.route.snapshot.params['medicalShopId'];

    this.service.getMedicalShop(this.shopId)
    .subscribe(data => {
      console.log(data)
      this.shops = data;
    }, error => console.log(error));
  }
  list() {
    this.router.navigate(['displayadmin/medicalshop']);
  }
}
