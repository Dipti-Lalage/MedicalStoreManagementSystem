import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { MedicalShopService } from '../medical-shop.service';

@Component({
  selector: 'app-display-page',
  templateUrl: './display-page.component.html',
  styleUrls: ['./display-page.component.css']
})
export class DisplayPageComponent implements OnInit {
  IsOwnerLogin:any;
  constructor(private service:MedicalShopService) {
    
   }

  ngOnInit(): void {
    this.IsOwnerLogin=this.service.getOwnerLogin;

  }

}
