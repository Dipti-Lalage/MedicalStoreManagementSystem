
import { Component, OnInit } from '@angular/core';
import { ActivatedRouteSnapshot, Router, RouterStateSnapshot } from '@angular/router';
import { MedicalShopService } from '../medical-shop.service';
import { MedicalShop } from '../medicalshop.model';
import {NgForm} from '@angular/forms';
import { Staff } from 'src/app/staff/staff.model';
import { StaffService } from 'src/app/staff/staff.service';

@Component({
  selector: 'app-loginowner',
  templateUrl: './loginowner.component.html',
  styleUrls: ['./loginowner.component.css']
})
export class LoginownerComponent implements OnInit {

  owner:MedicalShop=new MedicalShop();
  submitted
  ownerData:MedicalShop;
  ownerId:number;
  msg='';
  staff:Staff;
  ownerInfo:any;
  constructor(private router:Router,private service:MedicalShopService,private staffservice:StaffService) { }

  ngOnInit(): void {
    this.ownerData=new MedicalShop();
    this.ownerId=this.ownerData.medicalShopId;
    this.staff=new Staff();
  }
  GetValidOwner() {
    this.service.getOwnerLogin(this.owner)
      .subscribe(data => {console.log(data);
        this.ownerInfo=data;
        this.ownerData=this.ownerInfo;

        console.log(this.ownerData);
        localStorage.setItem('owner',JSON.stringify(this.ownerData));
        this.msg="Login Successfull"; 
        this.gotoaddStaff();
      }, 
      error =>{console.log(error);
        this.router.navigate(['/medicalshop/ownerlogin']);
        this.msg='Invalid login details...please try again';
      });
     this.owner = new MedicalShop();
  }

  onSubmit() {
    this.GetValidOwner();    
  }
  gotoaddStaff(){  
    this.router.navigate(['displayowner']);
  }z
}
