import { TestBed } from '@angular/core/testing';

import { MedicalShopService } from './medical-shop.service';

describe('MedicalShopService', () => {
  let service: MedicalShopService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(MedicalShopService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
