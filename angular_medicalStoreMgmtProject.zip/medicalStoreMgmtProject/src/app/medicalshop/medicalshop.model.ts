export class MedicalShop{
                 medicalShopId:number;
                 medicalShopName:string;
                 medicalShopAddress:string;
                 ownerName:string;
                 ownerMobile:string;
                 ownerEmail:string;
                 ownerPassword:string;
                 ownerAddress:string;
                 medicalShopDescription:string;
}