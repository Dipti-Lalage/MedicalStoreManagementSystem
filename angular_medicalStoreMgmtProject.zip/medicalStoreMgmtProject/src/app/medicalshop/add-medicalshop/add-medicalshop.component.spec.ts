import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddMedicalshopComponent } from './add-medicalshop.component';

describe('AddMedicalshopComponent', () => {
  let component: AddMedicalshopComponent;
  let fixture: ComponentFixture<AddMedicalshopComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddMedicalshopComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AddMedicalshopComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
