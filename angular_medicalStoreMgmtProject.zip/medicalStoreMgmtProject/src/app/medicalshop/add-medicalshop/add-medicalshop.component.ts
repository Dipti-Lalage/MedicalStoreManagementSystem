import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MedicalShopService } from '../medical-shop.service';
import { MedicalShop } from '../medicalshop.model';

@Component({
  selector: 'app-add-medicalshop',
  templateUrl: './add-medicalshop.component.html',
  styleUrls: ['./add-medicalshop.component.css']
})
export class AddMedicalshopComponent implements OnInit {

  constructor(private router:Router,private service:MedicalShopService) { }

  shops:MedicalShop=new MedicalShop();
  submitted
  msg='';
  ngOnInit(): void {
  }
  saveMedicalShop() {
    this.service.createMedicalShop(this.shops)
      .subscribe(data =>{ console.log(data);
        this.gotoList();
      }, error => {console.log(error);
         this.msg="Data insertion unsuccessfull";
      });
    this.shops = new MedicalShop();
  
  }

  onSubmit(form) {
    this.saveMedicalShop();   
    form.submitted=false; 
  }

  gotoList(){
    this.router.navigate(['displayadmin/medicalshop']);
  }
}
