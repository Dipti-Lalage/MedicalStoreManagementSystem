import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { MedicalShopService } from '../medical-shop.service';
import { MedicalShop } from '../medicalshop.model';

@Component({
  selector: 'app-showmedicalshops',
  templateUrl: './showmedicalshops.component.html',
  styleUrls: ['./showmedicalshops.component.css']
})
export class ShowmedicalshopsComponent implements OnInit {

  medicalshops:Observable<MedicalShop[]>;
  constructor(private srvice:MedicalShopService,private router:Router) { }

  ngOnInit(): void {
    this.fetchMedicalShopList();
  }
   fetchMedicalShopList()
   {
     this.medicalshops=this.srvice.getMedicalShopList();
   }

   deleteMedicalShop(medicalshopid: number) {
    this.srvice.deleteMedicalShop(medicalshopid)
      .subscribe(
        data => {
          console.log(data);
          this.fetchMedicalShopList();
        },
        error => console.log(error));
  }

  MedicalShopDetails(shopID: number) {
    this.router.navigate(['shopdetails', shopID]);
  }

  updateMedical(shop:MedicalShop){
    this.router.navigate(['updateshop', shop]);
  }
}
