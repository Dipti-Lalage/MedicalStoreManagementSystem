import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { MedicalShopService } from '../medical-shop.service';
import { MedicalShop } from '../medicalshop.model';

@Component({
  selector: 'app-update-medicalshop',
  templateUrl: './update-medicalshop.component.html',
  styleUrls: ['./update-medicalshop.component.css']
})
export class UpdateMedicalshopComponent implements OnInit {
  shopId:number;
  shops:MedicalShop;

  constructor(private route:ActivatedRoute,private router:Router,
               private service:MedicalShopService) { }

  ngOnInit(): void {
    
    this.shops=new MedicalShop();
    this.shopId=this.route.snapshot.params['medicalShopId'];

    this.service.getMedicalShop(this.shopId)
    .subscribe(data=>{
      console.log(data);
      this.shops=data;
    },error=>console.error(error) );
    
  }
  updateMedicalShop()
  {
    this.service.updateMedicalShop(this.shops)
    .subscribe(data=>console.log(data),error=>console.log(error));
    this.shops=new MedicalShop();
    this.gotoList();
  }
  onSubmit() {
    this.updateMedicalShop();    
  }

  gotoList() {
    this.router.navigate(['displayadmin/medicalshop']);
  }
}
