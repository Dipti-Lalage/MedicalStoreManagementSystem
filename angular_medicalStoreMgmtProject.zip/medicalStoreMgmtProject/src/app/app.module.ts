import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ShowmedicalshopsComponent } from './medicalshop/showmedicalshops/showmedicalshops.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { UpdateMedicalshopComponent } from './medicalshop/update-medicalshop/update-medicalshop.component';
import { DetailsMedicalshopComponent } from './medicalshop/details-medicalshop/details-medicalshop.component';
import { AddMedicalshopComponent } from './medicalshop/add-medicalshop/add-medicalshop.component';
import { ShowCompanyComponent } from './company/show-company/show-company.component';
import { UpdateCompanyComponent } from './company/update-company/update-company.component';
import { DetailsCompanyComponent } from './company/details-company/details-company.component';
import { AddCompanyComponent } from './company/add-company/add-company.component';
import { ShowStaffComponent } from './staff/show-staff/show-staff.component';
import { AddStaffComponent } from './staff/add-staff/add-staff.component';
import { UpdateStaffComponent } from './staff/update-staff/update-staff.component';
import { DetailsStaffComponent } from './staff/details-staff/details-staff.component';
import { LoginownerComponent } from './medicalshop/loginowner/loginowner.component';
import { DisplayPageComponent } from './medicalshop/display-page/display-page.component';
import { StaffLoginComponent } from './staff/staff-login/staff-login.component';
import { DisplayStaffComponent } from './staff/display-staff/display-staff.component';
import { ShowMedicinesComponent } from './medicines/show-medicines/show-medicines.component';
import { DetailsMedicineComponent } from './medicines/details-medicine/details-medicine.component';
import { UpdateMedicineComponent } from './medicines/update-medicine/update-medicine.component';
import { AddMedicinesComponent } from './medicines/add-medicines/add-medicines.component';
import { AdminLoginComponent } from './admin/admin-login/admin-login.component';
import { AdminDisplayComponent } from './admin/admin-display/admin-display.component';





@NgModule({
  declarations: [
    AppComponent,
    ShowmedicalshopsComponent,
    UpdateMedicalshopComponent,
    DetailsMedicalshopComponent,
    AddMedicalshopComponent,
    ShowCompanyComponent,
    UpdateCompanyComponent,
    DetailsCompanyComponent,
    AddCompanyComponent,
    ShowStaffComponent,
    AddStaffComponent,
    UpdateStaffComponent,
    DetailsStaffComponent,
    DetailsMedicalshopComponent,
    LoginownerComponent,
    DisplayPageComponent,
    StaffLoginComponent,
    DisplayStaffComponent,
    ShowStaffComponent,
    ShowMedicinesComponent,
    DetailsMedicineComponent,
    UpdateMedicineComponent,
    AddMedicinesComponent,
    AdminLoginComponent,
    AdminDisplayComponent
   
  
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule

  
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
