import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Staff } from './staff.model';

@Injectable({
  providedIn: 'root'
})
export class StaffService {
  private baseUrl = 'http://localhost:8080';

  constructor(private http:HttpClient) { }

  AddNewStaff(staff:Object): Observable<Object> {
    
    console.log(staff);
    return this.http.post(this.baseUrl+'/staff/', staff);
  }

  updateStaffDetails(staff: Object): Observable<Object> {
    console.log(staff);
    return this.http.put(this.baseUrl+'/staff/',JSON.stringify(staff),
    {headers:{'Content-Type':'application/json;charset=UTF-8'}});
  }

  deleteStaffById(staffId:number): Observable<any> {
    return this.http.delete(this.baseUrl+'/staff/'+staffId);
  }

  getStaffList(): Observable<any> {
    return this.http.get(this.baseUrl+'/staff/');
  }
  getStaffDetailsById(staffid: number): Observable<any> {
    return this.http.get(this.baseUrl+'/staff/'+staffid);
  }

  getStaffLogin(staff:Object):Observable<Object>{
    return this.http.post(this.baseUrl+'/staff/stafflogin/', staff);
  }
}
