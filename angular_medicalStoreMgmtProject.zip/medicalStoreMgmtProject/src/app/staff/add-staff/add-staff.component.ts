import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { MedicalShopService } from 'src/app/medicalshop/medical-shop.service';
import { MedicalShop } from 'src/app/medicalshop/medicalshop.model';
import { Staff } from '../staff.model';
import { StaffService } from '../staff.service';

@Component({
  selector: 'app-add-staff',
  templateUrl: './add-staff.component.html',
  styleUrls: ['./add-staff.component.css']
})
export class AddStaffComponent implements OnInit {
  staffdata:any;
  constructor(private service:StaffService,private router:Router,
    private mshopservice:MedicalShopService) { }
   
  staff:Staff=new Staff();
  submitted
  msg='';
  
  shopid:number;
  ownerId:MedicalShop;
  ngOnInit(): void {
  
      this.ownerId=JSON.parse(localStorage.getItem('owner'));
      console.log(this.ownerId);
      this.staff.medicalShopId=this.ownerId;
      console.log(this.staff.medicalShopId);
      }
  saveStaff() {
  
    this.service.AddNewStaff(this.staff)
      .subscribe(data => {console.log(data);
         console.log(data);
         this.staff.medicalShopId=this.ownerId;
        this.gotoList();
      },
       error =>{ console.log(error);
      this.msg="Data insertion unsuccessfull";
      });
    this.staff = new Staff();
    
  }
    onSubmit(form) {
      this.saveStaff(); 
      form.submitted=false;   
    }
   
  
    gotoList(){
      this.router.navigate(['displayowner/staff']);
    }
}
