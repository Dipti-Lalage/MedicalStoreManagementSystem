import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MedicalShop } from 'src/app/medicalshop/medicalshop.model';
import { Staff } from '../staff.model';
import { StaffService } from '../staff.service';

@Component({
  selector: 'app-staff-login',
  templateUrl: './staff-login.component.html',
  styleUrls: ['./staff-login.component.css']
})
export class StaffLoginComponent implements OnInit {

  staff:Staff=new Staff();
  submitted
  ownerId:any;
  msg='';
  ownerInfo:any;
  ownerData:MedicalShop;
  constructor(private router:Router,private service:StaffService) { }

  ngOnInit(): void {
  }
  GetValidSatff() {
    this.service.getStaffLogin(this.staff)
      .subscribe(data => {console.log(data);
        this.ownerInfo=data;
        this.ownerData=this.ownerInfo.medicalShopId;
        console.log(this.ownerData);
        localStorage.setItem('staffowner',JSON.stringify(this.ownerData));
        this.router.navigate(['staffdisplay']);
      }
      , error => {console.log(error);
        this.router.navigate(['/staff/stafflogin']);
        this.msg='Invalid login details...please try again';
      });
     this.staff = new Staff();
    this.gotoList();
  }

  onSubmit() {
    this.GetValidSatff();    
  }

  gotoList(){
    
  }
}
