import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { MedicalShop } from 'src/app/medicalshop/medicalshop.model';
import { Staff } from '../staff.model';
import { StaffService } from '../staff.service';

@Component({
  selector: 'app-show-staff',
  templateUrl: './show-staff.component.html',
  styleUrls: ['./show-staff.component.css']
})
export class ShowStaffComponent implements OnInit {
 staffs:Observable<Staff[]>;

  constructor(private service:StaffService,private router:Router) { }
 

  ngOnInit(): void {
    this.fetchStaffList();
  }
  fetchStaffList()
  {
    this.staffs=this.service.getStaffList();
  }

  deleteStaff(staffid: number) {
    this.service.deleteStaffById(staffid)
      .subscribe(
        data => {
          console.log(data);
          this.fetchStaffList();
        },
        error => console.log(error));
  }
  StaffDetailsById(staffid: number) {
    this.router.navigate(['staffdetails', staffid]);
  }

  updateStaffDetails(staff:Staff){
    this.router.navigate(['updatestaff', staff]);
  }
}
