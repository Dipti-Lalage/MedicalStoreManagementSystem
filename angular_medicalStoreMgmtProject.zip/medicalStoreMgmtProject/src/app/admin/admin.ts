export class Admin {
    adminId:number;
    adminName:string;
    adminMobile:string;
    adminEmail:string;
    adminPassword:string;
}
