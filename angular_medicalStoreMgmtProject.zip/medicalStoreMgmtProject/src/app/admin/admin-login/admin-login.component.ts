import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Admin } from '../admin';
import { AdminService } from '../admin.service';

@Component({
  selector: 'app-admin-login',
  templateUrl: './admin-login.component.html',
  styleUrls: ['./admin-login.component.css']
})
export class AdminLoginComponent implements OnInit {
 admin:Admin=new Admin();
 submitted
 msg='';
  constructor(private router:Router,private service:AdminService) { }

  ngOnInit(): void {
  }
  GetValidAdmin() {
    this.service.getAdminLogin(this.admin)
      .subscribe(data => {console.log(data);
        this.router.navigate(['displayadmin']);
      }  
      , error => {console.log(error);
        this.router.navigate(['/admin/adminlogin']);
        this.msg='Invalid login details...please try again';
      });
  
  }

  onSubmit() {
    this.GetValidAdmin();    
  }


}
