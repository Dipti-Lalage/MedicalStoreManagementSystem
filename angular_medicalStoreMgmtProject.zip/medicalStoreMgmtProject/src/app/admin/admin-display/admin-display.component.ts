import { Component, OnInit } from '@angular/core';
import { AdminService } from '../admin.service';

@Component({
  selector: 'app-admin-display',
  templateUrl: './admin-display.component.html',
  styleUrls: ['./admin-display.component.css']
})
export class AdminDisplayComponent implements OnInit {
  IsAdminLogin:any;
  constructor(private service:AdminService) { }

  ngOnInit(): void {
    this.getloginfo();
    
  }
  getloginfo(){
    this.IsAdminLogin=this.service.getAdminLogin;
    if(this.IsAdminLogin)
    return true;
    else 
      return false;
  }
}
