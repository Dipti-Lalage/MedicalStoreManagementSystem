import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AdminDisplayComponent } from './admin-display/admin-display.component';



@NgModule({
  declarations: [AdminDisplayComponent],
  imports: [
    CommonModule
  ]
})
export class AdminModule { }
