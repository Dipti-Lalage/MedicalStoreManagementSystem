import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Medicine } from '../medicine';
import { MedicinesService } from '../medicines.service';

@Component({
  selector: 'app-show-medicines',
  templateUrl: './show-medicines.component.html',
  styleUrls: ['./show-medicines.component.css']
})
export class ShowMedicinesComponent implements OnInit {

  medicines:Observable<Medicine[]>;
  constructor(private service:MedicinesService,private router:Router) { }

  ngOnInit(): void {
    this.fetchMedicineList();
  }
  fetchMedicineList()
  {
    this.medicines=this.service.getMedicineList();
  }

  deleteMedicine(medicineid: number) {
   this.service.deleteMedicines(medicineid)
     .subscribe(
       data => {
         console.log(data);
         this.fetchMedicineList();
       },
       error => console.log(error));
 }

 medicineDetails(medicineid: number) {
   this.router.navigate(['medicinedetails', medicineid]);
 }

 updateMedicineDetails(medicine:Medicine){
   this.router.navigate(['updatemedicine', medicine]);
 }
}
