import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DetailsMedicineComponent } from './details-medicine/details-medicine.component';
import { ShowMedicinesComponent } from './show-medicines/show-medicines.component';
import { UpdateMedcineComponent } from './update-medcine/update-medcine.component';
import { UpdateMedicineComponent } from './update-medicine/update-medicine.component';
import { AddMedicinesComponent } from './add-medicines/add-medicines.component';



@NgModule({
  declarations: [DetailsMedicineComponent, ShowMedicinesComponent, UpdateMedcineComponent, UpdateMedicineComponent, AddMedicinesComponent],
  imports: [
    CommonModule
  ]
})
export class MedicinesModule { }
