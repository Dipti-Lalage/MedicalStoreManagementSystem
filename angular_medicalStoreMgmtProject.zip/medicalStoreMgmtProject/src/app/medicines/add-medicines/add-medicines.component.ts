import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MedicalShop } from 'src/app/medicalshop/medicalshop.model';
import { Medicine } from '../medicine';
import { MedicinesService } from '../medicines.service';

@Component({
  selector: 'app-add-medicines',
  templateUrl: './add-medicines.component.html',
  styleUrls: ['./add-medicines.component.css']
})
export class AddMedicinesComponent implements OnInit {

  constructor(private router:Router,private service:MedicinesService) { }

  medicines:Medicine=new Medicine();
  submitted
   
  ownerId:MedicalShop;
  ngOnInit(): void {
    this.ownerId=JSON.parse(localStorage.getItem('staffowner'));
    console.log(this.ownerId);
    this.medicines.medicalShopId=this.ownerId;
    console.log(this.medicines.medicalShopId);
  }
  saveMedicines() {
    this.service.AddNewMedcine(this.medicines)
      .subscribe(data => {console.log(data);
      this.medicines.medicalShopId=this.ownerId;
      this.gotoList();
      }
      , error => {console.log(error);});
     
    this.medicines = new Medicine();
   
    
  }

  onSubmit(form) {
    this.saveMedicines();  
    form.submitted=false;   
  }
gotoList()
  {
    this.router.navigate(['staffdisplay/medicines']);
  }

}
