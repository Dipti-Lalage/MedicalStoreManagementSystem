import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class MedicinesService {
  private baseUrl = 'http://localhost:8080';
  constructor(private http:HttpClient) { }
  
  AddNewMedcine(medicine:Object): Observable<Object> {
    return this.http.post(this.baseUrl+'/medicines/addmedicine/', medicine);
  }

  updateMedicineDetails(medicine: Object): Observable<Object> {
    console.log(medicine);
    return this.http.put(this.baseUrl+'/medicines/', medicine);
  }

  deleteMedicines(medicineid:number): Observable<any> {
    console.log(medicineid);
    return this.http.delete(this.baseUrl+'/medicines/'+medicineid);
  }

  getMedicineList(): Observable<any> {
    return this.http.get(this.baseUrl+'/medicines/');
  }
  getMedicineById(medicineid: number): Observable<any> {
    console.log(medicineid);
    return this.http.get(this.baseUrl+'/medicines/'+medicineid);
  }

 
}
