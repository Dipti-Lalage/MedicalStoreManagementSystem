import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { MedicalShop } from 'src/app/medicalshop/medicalshop.model';
import { Medicine } from '../medicine';
import { MedicinesService } from '../medicines.service';


@Component({
  selector: 'app-details-medicine',
  templateUrl: './details-medicine.component.html',
  styleUrls: ['./details-medicine.component.css']
})
export class DetailsMedicineComponent implements OnInit {
 
  medicineid:number;
  medicine:Medicine;
  shopid:number;
  shop:MedicalShop;
  msg="";
  constructor(private route:ActivatedRoute,private router:Router,
    private service:MedicinesService) { }

  ngOnInit(): void {
    this.medicine=new Medicine();
    this.medicineid=this.route.snapshot.params['medicineId'];
    this.service.getMedicineById(this.medicineid)
    .subscribe(data => {
      console.log(data)
      this.medicine = data;
      console.log("medicine",this.medicine);
      this.checkStock(this.medicine); 
    }, error => console.log(error));
  }
  list() {
    
    this.router.navigate(['staffdisplay/medicines']);
  }
  
  checkStock(medicine:Medicine):any
  {
    console.log("checkstock ",medicine);
    if(medicine.availbleStocks<=medicine.minimumStocks){
      console.log("in if");
        this.msg="Less stock available please increase stock..";
    }
  }
}
